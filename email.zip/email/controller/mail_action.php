<?php 
	require_once("../model/db_project.php");
	require_once "../assets/PHPMailer/class.PHPMailer.php";
	// echo "<pre>";
	// print_r($_POST); exit;
	$name=$_POST['name'];
	$email=$_POST['email'];
	$contact=$_POST['contact'];
	$message=$_POST['message'];


	$exp="/^[a-zA-Z]+( )?[a-zA-Z]+$/";
	 $exp_name=preg_match($exp,$_POST['name']);
	 if ($exp_name!==1)
	  {
	 	echo "Invalid Name";
	 }
	 else
	 {
	 	$exp="/^[0-9]+$/";
		 $contact=preg_match($exp,$_POST['contact']);
		 if ($contact!==1)
		  {
		 	echo "Invalid contact number";
		 }
		 else
		 {
		 	$rg_exp="/^([a-z0-9][a-z0-9_\.\-]{1,}[a-z0-9])@([a-z0-9][a-z0-9_\-]{1,}[a-z0-9])([a-z]{2,})(\.[a-z]{2,})?$/";
			 $exp_mail=preg_match($rg_exp,$_POST['email']);
			 if ($exp_mail!==1)
			 {
			 	echo "Invalid email";
			 }
			 else
			 {
			 	
				 if (empty($message))
				 {
				 	echo "Message filed is empty";
				 }
				 else
				 {
				 		$result=$obj->select("*","register","email='$email'");

						if($result!=FALSE)
						{
							echo "Email already exist";
						}
						else
						{
							//$obj->insert("register","name, contact, email, message","'$name', '$contact', '$email', '$message'");
							$email_id = $obj->email();
							 // ++++++++++++++++++++++++++++++++++++
								$mail = new PHPMailer();
								$mail->IsSMTP();                                      // set mailer to use SMTP
								$mail->SMTPSecure = 'tls';
								$mail->Host = "smtp.outlook.office365.com";
								$mail->Port = 587;
								//$mail->SMTPDebug  = 2; 
								$mail->SMTPAuth = true;     // turn on SMTP authentication
								$mail->Username = "youremailid";  // SMTP username
								$mail->Password = "paword"; // SMTP password

								$mail->From = "emailid";
								$mail->FromName = "name";
								// $mail->AddAddress("shashim2507@gmail.com", "Shashi");
								$mail->AddAddress=$email_id;
								//$mail->AddAddress("ellen@example.com");                  // name is optional
								$mail->AddReplyTo("email@outlook.com", "name");

								$mail->WordWrap = 50;                                 // set word wrap to 50 characters
								//$mail->AddAttachment("/var/tmp/file.tar.gz");         // add attachments
								//$mail->AddAttachment("/tmp/image.jpg", "new.jpg");    // optional name
								$mail->IsHTML(true);                                  // set email format to HTML

								$mail->Subject = "Contact form";
								$mail->Body    = "Message has been sent";
								//$mail->AltBody = "This is the body in plain text for non-HTML mail clients";

								if(!$mail->Send())
								{
								   echo "Message could not be sent. 
								";
								   echo "Mailer Error: " . $mail->ErrorInfo;
								   exit;
								}
								else{

									echo "Message has been sent";
									echo 1;
								}
								
						}
				 }
			 }
		 }
	 }

 ?>