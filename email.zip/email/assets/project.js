$(document).ready(function() {


///////////////////////////// contact //////////////////////
  $('.btn-rg').on('click', function(event) {
  	 event.preventDefault();
      $.ajax({
          type:'post',
          data:$('#signupForm').serialize(),
          url:'../controller/mail_action.php',
          success:function(res)
          {
            if(res==1)
              {
                 $(".error").html(res);
              }
              else
              {
                $(".error").html("Message has been sent");
                $(".error").css({"background-color": 'indianred',"color" : "white", "padding": "10px", "text-align": "center" , "margin-bottom": "10px"
                          });
              }
          }
        })
  });
/////////////////////////////   //////////////////////
 
/////////////////////////////////////////////

});




