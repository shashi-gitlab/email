<script type="text/javascript">
	window.location.href="view/index.php";
</script>