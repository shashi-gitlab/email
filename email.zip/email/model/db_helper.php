<?php 
require_once("db_connect.php");

	abstract class db_helper extends db_connect
		{
			function insert($table, $record, $value)
			{
				$str="insert into $table ($record) values($value)";
				$result=mysqli_query($this->conn, $str) or die(mysqli_error($this->conn));
			}

			function select($col, $table, $cond)
			{
				$str="select $col from $table where $cond";
				$result=mysqli_query($this->conn, $str) or die(mysqli_error($this->conn));

				if($result->num_rows>0)
				{
					while($ans=$result->fetch_assoc())
					{
						$data[]= $ans;
					}
					return $data;
				}
				else
				{
					return 0;
				}
			}

			function cnt($table, $cond)
			{
				$ans=$this->select("count(*) as cnt", $table, $cond);
				echo "<pre>";
				print_r($ans);
			}
		
		}

			
 ?>