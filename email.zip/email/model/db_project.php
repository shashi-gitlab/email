<?php 
require_once("db_helper.php");

	final class db_project extends db_helper
		{
			
			
			function email()
			{
				return self::select("email","register"," 1 order by id DESC LIMIT 1");
			}
			

		}

		$obj= new db_project();
	
 ?>